"""
ConsciousAI Interface - Пользовательский интерфейс
CLI, команды, взаимодействие
"""

# TODO: Добавить interface компоненты после создания
# from .cli import SimpleInterface
# from .commands import CommandHandler

__all__ = []
