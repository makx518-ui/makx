# 🤖 TRADING BOT AI - Супер код

**Мощный AI бот для анализа крипты, форекса и сырья**

Написан с нуля на основе лучших практик из бота Оракул.

---

## ✨ ФИЧИ

### 📊 **Анализирует:**
- **Крипта:** BTC, ETH, SOL, BNB, XRP, ADA, DOGE, MATIC, AVAX, DOT
- **Форекс:** EUR/USD, GBP/USD, USD/JPY, AUD/USD, USD/CHF, USD/CAD
- **Commodities:** Золото, Серебро, Нефть, Газ, Медь

### 🤖 **AI Агенты:**
1. **Technical Agent** - RSI, Volume, Price Action
2. **Smart Money Agent** - Киты, накопление/распределение
3. **Sentiment Agent** - Fear & Greed Index, импульс
4. **Meta Agent** - Синтез через Groq Llama 3.3 70B

### 🗣️ **Голосовая система:**
- Распознавание через Groq Whisper
- Озвучивание через Edge TTS
- Мультиязычность (RU/EN)

---

## 🚀 УСТАНОВКА

### 1. Установи зависимости:
```bash
pip install -r requirements.txt
```

### 2. Проверь .env файл:
Файл `.env` уже содержит твои API ключи (пример):
```
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here
GROQ_API_KEY=gsk_your_groq_api_key_here
NEWSDATA_API_KEY=pub_your_newsdata_api_key_here
FRED_API_KEY=your_fred_api_key_here
```

**Примечание:** В скачанном проекте файл `.env` уже содержит актуальные ключи!

### 3. Запусти бота:
```bash
python trading_bot.py
```

---

## 📖 КАК ПОЛЬЗОВАТЬСЯ

### **Через меню:**
1. Нажми `/start`
2. Выбери "📊 Анализ крипты"
3. Выбери актив (BTC, ETH...)
4. Получи AI-анализ + голосовое сообщение!

### **Голосом:**
1. Запиши голосовое сообщение
2. Скажи "Проанализируй Bitcoin" или "Analyze BTC"
3. Бот распознает и ответит!

---

## 🏗️ АРХИТЕКТУРА

```
TradingBot-AI-New/
├── trading_bot.py          ← ГЛАВНЫЙ ФАЙЛ
├── config.py               ← Настройки
├── .env                    ← API ключи
├── requirements.txt        ← Зависимости
│
├── voice/
│   └── voice_system.py     ← Голос (из Оракула)
│
├── data_sources/
│   ├── crypto_data.py      ← Binance + CoinGecko
│   └── forex_data.py       ← Форекс + Commodities
│
└── agents/
    ├── technical_agent.py      ← Технический анализ
    ├── smart_money_agent.py    ← Smart Money (киты)
    ├── sentiment_agent.py      ← Sentiment (Fear & Greed)
    └── meta_agent.py           ← Meta Agent (AI синтез)
```

---

## 🧠 КАК РАБОТАЕТ АНАЛИЗ

### **Шаг 1: Сбор данных**
- Цена с Binance API
- Market cap с CoinGecko
- Fear & Greed Index

### **Шаг 2: Агенты (параллельно)**
```python
Technical Agent:
- RSI сигнал
- Volume анализ
- Price action

Smart Money Agent:
- Активность китов
- Накопление/Распределение

Sentiment Agent:
- Fear & Greed (contrarian)
- Импульс рынка
```

### **Шаг 3: Meta Agent**
- Взвешенный score от агентов
- Детекция резонанса (согласие методов)
- AI финальное решение через Groq

### **Шаг 4: Ответ**
- Текстовый анализ
- Голосовое сообщение
- Рекомендация: BUY/SELL/HOLD

---

## 📊 ПРИМЕР ВЫВОДА

```
📊 СИГНАЛ: BUY
💪 УВЕРЕННОСТЬ: 78%

📈 ТЕХНИЧЕСКИЙ АНАЛИЗ:
RSI показывает oversold зону после сильного падения.
Объём растёт, что указывает на интерес покупателей.

🐋 SMART MONEY:
Крупные игроки активно накапливают позиции.
Отношение объёма к капитализации высокое.

💬 SENTIMENT:
Fear & Greed Index на уровне 28 (Extreme Fear) -
классический contrarian сигнал на покупку.

🎯 РЕКОМЕНДАЦИЯ:
Сильный BUY сигнал. Все три метода согласны.
Рекомендуется открытие длинной позиции с
целью на 5-7% выше текущей цены.

⚠️ РИСКИ:
Возможна краткосрочная волатильность.
Используй стоп-лосс на 3-4% ниже точки входа.
```

---

## 🔧 НАСТРОЙКИ

В `config.py` можно изменить:

### **Веса агентов:**
```python
AGENT_WEIGHTS = {
    "technical": 0.25,
    "smart_money": 0.30,
    "sentiment": 0.20,
    "macro": 0.15,
    "resonance": 0.10
}
```

### **Пороги сигналов:**
```python
CONFIDENCE_BUY = 0.75   # BUY если >= 75%
CONFIDENCE_SELL = 0.75  # SELL если >= 75%
CONFIDENCE_HOLD = 0.60  # HOLD если 60-75%
```

---

## 🎯 ДАЛЬНЕЙШЕЕ РАЗВИТИЕ

### **MVP (сейчас):**
- ✅ Анализ крипты (BTC, ETH, SOL...)
- ✅ 3 AI агента + Meta Agent
- ✅ Голосовая система
- ✅ Telegram интерфейс

### **Следующие шаги:**
- [ ] Форекс анализ (полная реализация)
- [ ] Commodities анализ
- [ ] Больше агентов (Macro, On-chain)
- [ ] Real-time whale tracking
- [ ] Backtesting
- [ ] Telegram алерты

---

## 📝 ЛОГИ

Все логи сохраняются в `trading_bot.log`

Чтобы следить за логами в реальном времени:
```bash
tail -f trading_bot.log
```

---

## 💡 СОВЕТЫ

1. **Начни с BTC/ETH** - самые стабильные данные
2. **Используй голос** - это быстрее!
3. **Смотри логи** - там видно как работают агенты
4. **Экспериментируй** - меняй веса в config.py

---

## 🐛 TROUBLESHOOTING

### Ошибка: "No module named 'edge_tts'"
```bash
pip install edge-tts
```

### Ошибка: "GROQ_API_KEY не установлен"
Проверь файл `.env` - должен быть ключ

### Бот не отвечает
1. Проверь логи: `cat trading_bot.log`
2. Проверь что бот запущен: `/start`
3. Попробуй другой актив

---

## 📞 ПОДДЕРЖКА

Telegram: @master_makx
Email: oracle.dreams@yandex.ru

---

**Успешной торговли! 🚀**
