# 🌙 Оракул Снов - Telegram Bot

Telegram бот для AI-анализа снов с демо-версией и системой подписки.

## 📋 Возможности

### Демо-версия (бесплатно)
- Показ демо-видео с примером работы
- Информация о возможностях полной версии
- Активация тестового периода (3 дня)

### Полная версия (подписка)
- ✨ Глубокий AI-анализ снов (Groq API)
- 📊 Интерактивная визуализация символов
- 🧠 Архетипический анализ по Юнгу
- 📈 График эмоциональной динамики
- 💡 Персональные инсайты
- 📚 История всех снов
- ♾️ Безлимитные анализы

## 📁 Структура проекта

```
makx/
├── bot.py                 # Основной код бота
├── subscriptions.py       # Модуль управления подписками
├── requirements.txt       # Зависимости Python
├── index.html            # Mini App - главная страница
├── demo.html             # Демо-версия с видео
├── script.js             # JavaScript для Mini App
├── style.css             # Стили Mini App
├── data/
│   ├── dreams/           # JSON-файлы с анализами снов
│   └── subscriptions.json # Данные о подписках
└── README.md             # Этот файл
```

## 🚀 Установка и запуск

### 1. Установите зависимости
```bash
pip install -r requirements.txt
```

### 2. Настройте переменные окружения
Создайте файл `.env` или установите переменные:
```bash
export GROQ_API_KEY="your_groq_api_key"
export TELEGRAM_TOKEN="your_telegram_bot_token"
export WEBAPP_URL="https://your-domain.com"  # URL для Amvera
```

### 3. Запустите бота
```bash
python bot.py
```

## 🌐 Деплой на Amvera

### 1. Загрузите файлы на Amvera
Все файлы из этой папки должны быть на сервере.

### 2. Настройте переменные окружения в Amvera
- `GROQ_API_KEY` - ваш API ключ Groq
- `TELEGRAM_TOKEN` - токен Telegram бота
- `WEBAPP_URL` - URL вашего приложения на Amvera (например: `https://yourapp.amvera.io`)

### 3. Настройте Telegram Bot
В BotFather укажите:
- Menu button URL: `https://yourapp.amvera.io/index.html`
- Domain для Mini App: `yourapp.amvera.io`

## 📱 Как работает бот

### Для пользователей БЕЗ подписки:
1. Пользователь отправляет текст сна
2. Бот показывает сообщение о демо-версии
3. Кнопки:
   - 🎬 Посмотреть демо → открывает demo.html
   - 💎 Оформить подписку → меню подписки

### Для пользователей С подпиской:
1. Пользователь отправляет текст сна
2. Бот анализирует сон с помощью Groq AI
3. Отправляет трактовку и кнопку визуализации
4. Сохраняет данные в JSON

## 🎬 Добавление демо-видео

Отредактируйте `demo.html`, строка 60-70:

### Вариант 1: YouTube видео
```html
<div class="video-wrapper">
    <iframe src="https://www.youtube.com/embed/YOUR_VIDEO_ID"
            frameborder="0" allowfullscreen></iframe>
</div>
```

### Вариант 2: Локальное видео
```html
<div class="video-wrapper">
    <video controls>
        <source src="demo-video.mp4" type="video/mp4">
    </video>
</div>
```

Не забудьте добавить видео-файл в проект и в `bot.py:31` добавить его в список статических файлов.

## 💳 Интеграция платежей (будущее)

Сейчас есть заглушка для оплаты. Для интеграции:

1. **ЮKassa / Stripe / PayPal**
   - Получите API ключи
   - Добавьте обработчик в `handle_callback` (bot.py:233)
   - Обновите `subscriptions.activate_subscription` после успешной оплаты

2. **Telegram Payments**
   - Используйте встроенную систему Telegram
   - Добавьте PreCheckoutQuery и SuccessfulPayment handlers

## 🔧 Управление подписками

### Активировать тестовый период вручную
```python
from subscriptions import activate_subscription
activate_subscription(user_id=123456, days=3)
```

### Проверить статус подписки
```python
from subscriptions import is_premium_user, get_subscription_info
is_premium = is_premium_user(123456)
info = get_subscription_info(123456)
```

### Файл подписок
Данные хранятся в `data/subscriptions.json`:
```json
{
  "123456": {
    "activated": "2025-01-01T10:00:00",
    "expiry": "2025-01-04T10:00:00",
    "days": 3
  }
}
```

## 📝 TODO (на будущее)

- [ ] Интеграция платежной системы
- [ ] Автопродление подписок
- [ ] Уведомления об окончании подписки
- [ ] Админ-панель для управления пользователями
- [ ] Статистика использования
- [ ] Экспорт истории снов
- [ ] Поделиться анализом сна

## 🐛 Отладка

### Логи
Бот пишет логи в консоль. Проверьте:
```bash
tail -f logs/bot.log  # если настроили логирование в файл
```

### Проблемы с подпиской
Если пользователь не видит полный функционал:
1. Проверьте `data/subscriptions.json`
2. Убедитесь что дата `expiry` в будущем
3. Формат даты: ISO 8601 (`2025-01-04T10:00:00`)

### Проблемы с Mini App
1. Убедитесь что `WEBAPP_URL` правильный
2. Проверьте что статические файлы доступны по `https://yourdomain/demo.html`
3. В Telegram проверьте Settings → Privacy → Mini Apps

## 📞 Контакты

Вопросы и предложения - создайте Issue в репозитории.

---

Сделано с 💜 для Оракула Снов
